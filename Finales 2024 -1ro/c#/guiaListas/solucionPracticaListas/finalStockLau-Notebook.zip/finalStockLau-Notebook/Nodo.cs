﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace finalStockLau_Notebook
{
    class Nodo
    {
        public int codigoProducto;
        public string nombreProducto;
        public double precioProducto;
        public int cantidadEnStock;
        public Nodo siguiente;
    }
}
